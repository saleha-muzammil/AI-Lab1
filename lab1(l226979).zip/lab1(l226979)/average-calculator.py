def get_numbers():
    """Recursively collects valid numbers from the user."""
    try:
        nums = list(map(float, input("Enter numbers separated by spaces: ").split()))
        return nums if nums else get_numbers()  # Ensure at least one valid number
    except ValueError:
        print("Invalid input. Please enter only numbers.")
        return get_numbers()

def calculate_average(numbers):
    """Returns the average of a list of numbers."""
    return sum(numbers) / len(numbers) if numbers else 0

# Example usage
if _name_ == "_main_":
    numbers = get_numbers()
    print(f"Average: {calculate_average(numbers):.2f}")