def celsius_to_fahrenheit(c):
    """Converts Celsius to Fahrenheit."""
    return (c * 9/5) + 32

def fahrenheit_to_celsius(f):
    """Converts Fahrenheit to Celsius."""
    return (f - 32) * 5/9

def get_conversion_choice():
    """Gets user's choice for conversion type."""
    choice = input("Convert:\n1. Celsius to Fahrenheit\n2. Fahrenheit to Celsius\nChoose (1/2): ")
    return choice if choice in ("1", "2") else get_conversion_choice()  # Ensures valid input

# Example usage
if _name_ == "_main_":
    choice = get_conversion_choice()
    temp = float(input("Enter the temperature: "))
    
    if choice == "1":
        print(f"{temp}°C = {celsius_to_fahrenheit(temp):.2f}°F")
    else:
        print(f"{temp}°F = {fahrenheit_to_celsius(temp):.2f}°C")