def fibonacci(n):
    """Returns the first n numbers in the Fibonacci sequence."""
    def fib_helper(a, b, count):
        return [] if count == 0 else [a] + fib_helper(b, a + b, count - 1)
    
    return fib_helper(0, 1, n)

# Example usage
if _name_ == "_main_":
    n = int(input("Enter the number of Fibonacci terms: "))
    print(fibonacci(n))