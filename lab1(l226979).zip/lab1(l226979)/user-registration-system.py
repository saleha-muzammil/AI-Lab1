def register(users, username, password):
    """Registers a new user if the username is not already taken."""
    if username in users:
        print("Username already exists. Try a different one.")
        return users  # No modification, maintaining immutability
    return {**users, username: password}  # Returns a new dictionary with added user

def login(users, username, password):
    """Checks if the provided credentials are valid."""
    return users.get(username) == password

def main():
    users = {}  # Stores user credentials

    while True:
        choice = input("\n1. Register\n2. Login\n3. Exit\nChoose an option: ")
        
        if choice == "1":
            username = input("Enter username: ")
            password = input("Enter password: ")
            users = register(users, username, password)
            print("Registration successful!")

        elif choice == "2":
            username = input("Enter username: ")
            password = input("Enter password: ")
            if login(users, username, password):
                print("Login successful!")
            else:
                print("Invalid credentials.")

        elif choice == "3":
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again.")

if _name_ == "_main_":
    main()