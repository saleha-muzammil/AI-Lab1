fruits = ['apple', 'banana', 'cherry']
fruits.append('date')
fruits.remove('banana')
for i in fruits:
    print(i.upper())

