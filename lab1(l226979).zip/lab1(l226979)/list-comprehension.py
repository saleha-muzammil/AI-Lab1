def square_numbers(numbers):
    return [n ** 2 for n in numbers]#returns a new list with the squares of each number using list comprehension.

def main():
    numbers = [1, 2, 3, 4, 5]
    print(f"input list : {numbers}")
    result = square_numbers(numbers)
    print(f"squared input list : {result}" )

main()
