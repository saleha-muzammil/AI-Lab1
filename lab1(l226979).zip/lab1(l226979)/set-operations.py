list1=[]
list2=[]

for i in range(0,5):
    a=int(input('enter integers for set1: '))
    list1.append(a)
print(list1)
for i in range(0,5):
    b=int(input('enter integers for set2: '))
    list2.append(b)
print(list2)

union = set(list1) | set(list2)
print("Union of set1 and set2 is: ", union)
intersection = set(list1) & set(list2)
print("Intersection of set1 and set2 is: ", intersection)
difference = set(list1) - set(list2)
print("Difference of set1 and set2 is: ", difference)
