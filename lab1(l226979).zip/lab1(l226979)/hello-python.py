name = input("What is your name? ")
age = input("How old are you? ")
print(f"Hello, {name}! You are {age} years old.")
