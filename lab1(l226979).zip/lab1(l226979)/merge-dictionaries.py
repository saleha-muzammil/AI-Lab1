dict1 = {'a': 1, 
         'b': 2, 
         'c': 3}
print(f"dictionary 1: {dict1}")
dict2 = {'b': 4, 
         'd': 5}
print(f"dictionary 2: {dict2}")
merged_dict = dict1 | dict2 #if u want to give presedence to dict1 (dict2|dict1) and cant use 'or' nstead of '|'
print(f"after merging: {merged_dict}")

 