def generate_table():
    """Generates a multiplication table from 1 to 10."""
    return [[i * j for j in range(1, 11)] for i in range(1, 11)]

def print_table(table):
    """Prints the multiplication table in a formatted way."""
    for row in table:
        print("  ".join(map(str, row)))

# Example usage
if _name_ == "_main_":
    table = generate_table()
    print_table(table)