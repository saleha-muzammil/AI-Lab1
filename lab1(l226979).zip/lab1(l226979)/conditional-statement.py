input_=int(input("enter integer: "))

#check nature of number 
if input_>0:
    print("positive")
elif input_==0:
    print("zero")
else:
    print("negative")

#chcek type of number
if input_%2==0:
    print("even")
else:
    print("odd")

