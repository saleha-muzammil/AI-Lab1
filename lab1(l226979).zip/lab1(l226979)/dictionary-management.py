dictionary={
    "ARSHAH":'A',
    "WAREESHA":'A',
    "TALAL":'C',
    "JAMIL":'B',
    "DONA":'A'
}
print(dictionary)