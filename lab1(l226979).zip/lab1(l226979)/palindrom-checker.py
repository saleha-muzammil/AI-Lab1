def is_palindrome(s):
    #Remove spaces
    s = s.replace(" ", "")
    #Convert to lower case
    s = s.lower()
    #Compare the string with its reverse
    if s == s[::-1]:
        return True
    return False

def main():
    s="A man a plan a canal Panama"
    print(f"the string '{s}' is palindrome :{is_palindrome(s)}") 
    s="Hello"
    print(f"the string '{s}' is palindrome :{is_palindrome(s)}") 
main()