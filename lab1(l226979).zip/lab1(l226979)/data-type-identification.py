user_input = input("Enter something: ")
print("The type of your input is:", type(user_input))