def count_words(words):
    """Returns a dictionary with word frequencies."""
    return {word: words.count(word) for word in set(words)}

def get_words():
    """Takes user input and returns a list of words."""
    return input("Enter words separated by spaces: ").split()

# Example usage
if _name_ == "_main_":
    words = get_words()
    frequencies = count_words(words)
    
    print("\nWord Frequencies:")
    for word, count in frequencies.items():
        print(f"{word}: {count}")