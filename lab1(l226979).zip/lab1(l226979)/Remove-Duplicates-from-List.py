def remove_duplicates(input_list):
    seen = set()#will contain elements of list that has visited, it is set in nature
    output_list = []#will contain ordered outputlist with removed duplicates
    for i in input_list:
        if i not in seen:
            output_list.append(i)
            seen.add(i)        
    return output_list   
def main():
    list=[ 1, 2, 2, 3, 4, 4,
        5, 6, 6, 7, 1, 8, 8,
        9, 10, 10, 11, 12, 12 ]
    print(f"original list: {list}")
    print(f"list after removing duplicates: {remove_duplicates(list)}")

main()
